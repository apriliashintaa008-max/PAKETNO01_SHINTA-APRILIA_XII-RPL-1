<?php
session_start();
include 'config/koneksi.php';
if (!isset($_SESSION['login'])) { header("Location: login.php"); exit; }

// Tambah Kategori
if (isset($_POST['tambah'])) {
    $nama = $_POST['nama_kategori'];
    mysqli_query($conn, "INSERT INTO tb_kategori (nama_kategori) VALUES ('$nama')");
    header("Location: kategori.php");
}

// Hapus Kategori
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM tb_kategori WHERE id_kategori='$id'");
    header("Location: kategori.php");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kategori - SIPINJAM</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>body { font-family: 'Plus Jakarta Sans', sans-serif; }</style>
</head>
<body class="bg-[#F4F7FE] flex h-screen overflow-hidden">
    <aside class="w-72 bg-[#0B1437] text-white flex flex-col p-8">
        <div class="flex items-center gap-3 mb-10">
            <i class="fas fa-clipboard-list text-2xl text-blue-500"></i>
            <h1 class="text-xl font-black uppercase tracking-tighter">SIPINJAM</h1>
        </div>
        <nav class="space-y-1 flex-1 overflow-y-auto pr-2">
            <a href="dashboard.php" class="flex items-center gap-4 p-4 text-gray-400 hover:text-white font-semibold mb-4"><i class="fas fa-home"></i> Dashboard</a>
            <p class="text-[10px] text-gray-500 font-black uppercase tracking-widest pt-4 pb-2">Master</p>
            <a href="user.php" class="flex items-center gap-4 p-4 text-gray-400 hover:text-white font-semibold"><i class="fas fa-user"></i> User</a>
            <a href="alat.php" class="flex items-center gap-4 p-4 text-gray-400 hover:text-white font-semibold"><i class="fas fa-tools"></i> Alat</a>
            <a href="kategori.php" class="flex items-center gap-4 bg-blue-600 p-4 rounded-2xl font-bold text-white shadow-lg shadow-blue-900/20"><i class="fas fa-tags"></i> Kategori</a>
        </nav>
    </aside>

    <main class="flex-1 p-10 overflow-y-auto">
        <h2 class="text-3xl font-black text-[#1B2559] mb-10">Data Kategori</h2>
        
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div class="bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-50 h-fit">
                <form action="" method="POST" class="space-y-4">
                    <label class="block text-sm font-bold text-[#1B2559]">Nama Kategori Baru</label>
                    <input type="text" name="nama_kategori" placeholder="Contoh: Multimedia" required class="w-full bg-gray-50 border border-gray-100 p-4 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <button type="submit" name="tambah" class="w-full bg-blue-600 text-white font-bold py-4 rounded-2xl hover:scale-105 transition-all">Tambah Kategori</button>
                </form>
            </div>

            <div class="lg:col-span-2 bg-white rounded-[2.5rem] p-8 shadow-sm border border-gray-50">
                <table class="w-full text-left">
                    <thead>
                        <tr class="text-gray-400 text-[11px] font-black uppercase tracking-widest border-b border-gray-100">
                            <th class="pb-6 pl-4">No</th>
                            <th class="pb-6">Nama Kategori</th>
                            <th class="pb-6 text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-50">
                        <?php 
                        $no = 1;
                        $q = mysqli_query($conn, "SELECT * FROM tb_kategori ORDER BY id_kategori DESC");
                        while($row = mysqli_fetch_assoc($q)): 
                        ?>
                        <tr class="hover:bg-gray-50/50">
                            <td class="py-6 pl-4 font-bold text-[#1B2559]"><?= $no++ ?></td>
                            <td class="py-6 font-bold text-[#1B2559]"><?= $row['nama_kategori'] ?></td>
                            <td class="py-6 flex justify-center gap-2">
                                <a href="?hapus=<?= $row['id_kategori'] ?>" onclick="return confirm('Hapus kategori ini?')" class="w-10 h-10 rounded-xl border border-red-100 flex items-center justify-center text-red-400 hover:bg-red-500 hover:text-white transition-all">
                                    <i class="fas fa-trash text-xs"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</body>
</html>