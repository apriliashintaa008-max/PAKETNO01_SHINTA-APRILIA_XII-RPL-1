<?php
session_start();
include 'config/koneksi.php';
if (!isset($_SESSION['login'])) { header("Location: login.php"); exit; }

if (isset($_POST['ajukan'])) {
    $tgl_pinjam = $_POST['tgl_pinjam'];
    $id_alat = $_POST['id_alat'];
    $jumlah = $_POST['jumlah'];
    $keperluan = $_POST['keperluan'];
    $id_user = $_SESSION['id_user'];

    $query = "INSERT INTO tb_peminjaman (id_user, id_alat, tgl_pinjam, jumlah, keperluan, status) 
              VALUES ('$id_user', '$id_alat', '$tgl_pinjam', '$jumlah', '$keperluan', 'Menunggu')";
    
    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Peminjaman berhasil diajukan!'); window.location='peminjaman.php';</script>";
    }
}

// --- LOGIKA PERSETUJUAN (ADMIN/PETUGAS) ---
if (isset($_GET['aksi']) && isset($_GET['id'])) {
    $status = ($_GET['aksi'] == 'setuju') ? 'Disetujui' : 'Ditolak';
    $id = $_GET['id'];
    mysqli_query($conn, "UPDATE tb_peminjaman SET status = '$status' WHERE id_peminjaman = '$id'");
    header("Location: peminjaman.php");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Peminjaman - SIPINJAM</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>body { font-family: 'Plus Jakarta Sans', sans-serif; }</style>
</head>
<body class="bg-[#F4F7FE] flex h-screen overflow-hidden">

    <aside class="w-72 bg-[#0B1437] text-white flex flex-col p-8">
        <div class="flex items-center gap-3 mb-10">
            <i class="fas fa-clipboard-list text-2xl text-blue-500"></i>
            <h1 class="text-xl font-black tracking-tighter uppercase">SIPINJAM</h1>
        </div>
        <nav class="space-y-1 flex-1 overflow-y-auto">
            <a href="dashboard.php" class="flex items-center gap-4 p-4 text-gray-400 hover:text-white font-semibold mb-4"><i class="fas fa-home"></i> Dashboard</a>
            <p class="text-[10px] text-gray-500 font-black uppercase tracking-widest pt-4 pb-2">Transaksi</p>
            <a href="peminjaman.php" class="flex items-center gap-4 bg-blue-600 p-4 rounded-2xl font-bold text-white shadow-lg shadow-blue-900/20"><i class="fas fa-receipt"></i> Peminjaman</a>
            <a href="pengembalian.php" class="flex items-center gap-4 p-4 text-gray-400 hover:text-white font-semibold"><i class="fas fa-undo"></i> Pengembalian</a>
        </nav>
    </aside>

    <main class="flex-1 p-10 overflow-y-auto">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-10">
            
            <section>
                <h2 class="text-2xl font-black text-[#1B2559] mb-6">Ajukan Peminjaman</h2>
                <div class="bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-50">
                    <form action="" method="POST" class="space-y-5">
                        <div>
                            <label class="block text-sm font-bold text-[#1B2559] mb-2">Tanggal Pinjam</label>
                            <input type="date" name="tgl_pinjam" required class="w-full bg-gray-50 border border-gray-100 p-4 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        <div>
                            <label class="block text-sm font-bold text-[#1B2559] mb-2">Pilih Alat</label>
                            <select name="id_alat" class="w-full bg-gray-50 border border-gray-100 p-4 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500">
                                <?php
                                $alats = mysqli_query($conn, "SELECT * FROM tb_alat WHERE stok > 0");
                                while($a = mysqli_fetch_assoc($alats)) {
                                    echo "<option value='".$a['id_alat']."'>".$a['nama_alat']." (Stok: ".$a['stok'].")</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-bold text-[#1B2559] mb-2">Jumlah</label>
                            <input type="number" name="jumlah" value="1" min="1" class="w-full bg-gray-50 border border-gray-100 p-4 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        <div>
                            <label class="block text-sm font-bold text-[#1B2559] mb-2">Keperluan</label>
                            <textarea name="keperluan" rows="3" placeholder="Contoh: Keperluan presentasi proyek UKK" class="w-full bg-gray-50 border border-gray-100 p-4 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500"></textarea>
                        </div>
                        <div class="flex gap-4 pt-2">
                            <button type="reset" class="flex-1 bg-gray-100 text-gray-500 font-bold py-4 rounded-2xl hover:bg-gray-200 transition-all">Batal</button>
                            <button type="submit" name="ajukan" class="flex-1 bg-blue-600 text-white font-bold py-4 rounded-2xl shadow-lg shadow-blue-200 hover:scale-105 transition-all">Ajukan Peminjaman</button>
                        </div>
                    </form>
                </div>
            </section>

            <section>
                <h2 class="text-2xl font-black text-[#1B2559] mb-6">Persetujuan Peminjaman</h2>
                <div class="bg-white rounded-[2.5rem] shadow-sm border border-gray-50 overflow-hidden">
                    <div class="flex border-b border-gray-50 px-4">
                        <button class="p-6 text-blue-600 border-b-2 border-blue-600 font-bold text-sm">Menunggu (<?php echo mysqli_num_rows(mysqli_query($conn, "SELECT id_peminjaman FROM tb_peminjaman WHERE status='Menunggu'")); ?>)</button>
                        <button class="p-6 text-gray-400 font-bold text-sm hover:text-blue-600 transition-all">Disetujui</button>
                        <button class="p-6 text-gray-400 font-bold text-sm hover:text-blue-600 transition-all">Ditolak</button>
                    </div>
                    
                    <div class="p-4">
                        <table class="w-full text-left">
                            <thead>
                                <tr class="text-gray-400 text-[11px] font-bold uppercase tracking-widest border-b border-gray-50">
                                    <th class="py-4 pl-4">No</th>
                                    <th class="py-4">Peminjam</th>
                                    <th class="py-4">Alat</th>
                                    <th class="py-4">Tanggal</th>
                                    <th class="py-4 text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-50">
                                <?php
                                $no = 1;
                                $query_m = mysqli_query($conn, "SELECT p.*, u.nama, a.nama_alat FROM tb_peminjaman p 
                                           JOIN tb_user u ON p.id_user = u.id_user 
                                           JOIN tb_alat a ON p.id_alat = a.id_alat 
                                           WHERE p.status = 'Menunggu' ORDER BY p.id_peminjaman DESC");
                                while($m = mysqli_fetch_assoc($query_m)):
                                ?>
                                <tr class="text-sm">
                                    <td class="py-4 pl-4 font-bold text-[#1B2559]"><?= $no++ ?></td>
                                    <td class="py-4 font-semibold text-[#1B2559]"><?= $m['nama'] ?></td>
                                    <td class="py-4 text-gray-500"><?= $m['nama_alat'] ?></td>
                                    <td class="py-4 text-gray-400 text-xs font-bold"><?= date('d M Y', strtotime($m['tgl_pinjam'])) ?></td>
                                    <td class="py-4 text-center">
                                        <div class="flex justify-center gap-2">
                                            <a href="?aksi=setuju&id=<?= $m['id_peminjaman'] ?>" class="bg-green-500 text-white text-[10px] px-3 py-1.5 rounded-lg font-bold hover:bg-green-600 transition-all shadow-sm shadow-green-100">Setuju</a>
                                            <a href="?aksi=tolak&id=<?= $m['id_peminjaman'] ?>" class="bg-red-500 text-white text-[10px] px-3 py-1.5 rounded-lg font-bold hover:bg-red-600 transition-all shadow-sm shadow-red-100">Tolak</a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>

        </div>
    </main>
</body>
</html>