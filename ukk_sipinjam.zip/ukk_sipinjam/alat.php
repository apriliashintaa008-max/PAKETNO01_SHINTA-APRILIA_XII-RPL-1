<?php
session_start();
include 'config/koneksi.php';
if (!isset($_SESSION['login'])) { header("Location: auth/login.php"); exit; }

// Logika Pencarian
$keyword = "";
if (isset($_POST['cari'])) {
    $keyword = $_POST['keyword'];
    $query = mysqli_query($conn, "SELECT a.*, k.nama_kategori FROM tb_alat a 
             LEFT JOIN tb_kategori k ON a.id_kategori = k.id_kategori 
             WHERE a.nama_alat LIKE '%$keyword%' ORDER BY a.id_alat DESC");
} else {
    $query = mysqli_query($conn, "SELECT a.*, k.nama_kategori FROM tb_alat a 
             LEFT JOIN tb_kategori k ON a.id_kategori = k.id_kategori 
             ORDER BY a.id_alat DESC");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Alat - SIPINJAM</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>body { font-family: 'Plus Jakarta Sans', sans-serif; }</style>
</head>
<body class="bg-[#F4F7FE] flex h-screen overflow-hidden">

    <aside class="w-72 bg-[#0B1437] text-white flex flex-col p-8">
        <div class="flex items-center gap-3 mb-10">
            <i class="fas fa-clipboard-list text-2xl text-blue-500"></i>
            <h1 class="text-xl font-black tracking-tighter uppercase">SIPINJAM</h1>
        </div>
        <nav class="space-y-1 flex-1 overflow-y-auto">
            <a href="dashboard.php" class="flex items-center gap-4 p-4 text-gray-400 hover:text-white font-semibold mb-4"><i class="fas fa-home"></i> Dashboard</a>
            <p class="text-[10px] text-gray-500 font-black uppercase tracking-widest pt-4 pb-2">Master</p>
            <a href="user.php" class="flex items-center gap-4 p-4 text-gray-400 hover:text-white font-semibold"><i class="fas fa-user"></i> User</a>
            <a href="alat.php" class="flex items-center gap-4 bg-blue-600 p-4 rounded-2xl font-bold text-white shadow-lg shadow-blue-900/20"><i class="fas fa-tools"></i> Alat</a>
            <a href="kategori.php" class="flex items-center gap-4 p-4 text-gray-400 hover:text-white font-semibold"><i class="fas fa-tags"></i> Kategori</a>
        </nav>
    </aside>

    <main class="flex-1 p-10 overflow-y-auto">
        <div class="flex justify-between items-center mb-10">
            <h2 class="text-3xl font-black text-[#1B2559]">Data Alat</h2>
            <button onclick="location.href='alat_tambah.php'" class="bg-[#4318FF] text-white px-6 py-3 rounded-2xl font-bold flex items-center gap-2 shadow-lg shadow-blue-200 hover:scale-105 transition-all">
                <i class="fas fa-plus"></i> Tambah Alat
            </button>
        </div>

        <div class="mb-8">
            <form action="" method="POST" class="relative max-w-sm">
                <input type="text" name="keyword" value="<?= $keyword ?>" placeholder="Cari alat..." class="w-full bg-white pl-12 pr-4 py-4 rounded-3xl text-sm focus:outline-none shadow-sm border border-gray-50">
                <i class="fas fa-search absolute left-5 top-1/2 -translate-y-1/2 text-gray-300"></i>
            </form>
        </div>

        <div class="bg-white rounded-[2.5rem] p-8 shadow-sm border border-gray-50">
            <table class="w-full text-left">
                <thead>
                    <tr class="text-gray-400 text-[13px] font-bold uppercase tracking-widest border-b border-gray-100">
                        <th class="pb-6 pl-4">No</th>
                        <th class="pb-6">Nama Alat</th>
                        <th class="pb-6">Kategori</th>
                        <th class="pb-6">Stok</th>
                        <th class="pb-6">Kondisi</th>
                        <th class="pb-6 pr-4 text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    <?php 
                    $no = 1;
                    while($row = mysqli_fetch_assoc($query)): 
                        // SOLUSI ERROR: Cek jika kolom kondisi ada, jika tidak set default "Baik"
                        $kondisi = isset($row['kondisi']) ? $row['kondisi'] : 'Baik';
                        $kondisi_class = ($kondisi == 'Baik') ? 'bg-green-50 text-green-500' : 'bg-orange-50 text-orange-500';
                    ?>
                    <tr class="hover:bg-gray-50/50 transition-all">
                        <td class="py-6 pl-4 font-bold text-[#1B2559] text-sm"><?= $no++ ?></td>
                        <td class="py-6 text-sm font-bold text-[#1B2559]"><?= $row['nama_alat'] ?></td>
                        <td class="py-6 text-sm font-semibold text-gray-400"><?= $row['nama_kategori'] ?></td>
                        <td class="py-6 text-sm font-bold text-[#1B2559]"><?= $row['stok'] ?></td>
                        <td class="py-6">
                            <span class="px-4 py-1.5 <?= $kondisi_class ?> rounded-xl text-[11px] font-black uppercase italic">
                                <?= $kondisi ?>
                            </span>
                        </td>
                        <td class="py-6 pr-4 text-center">
                            <div class="flex justify-center gap-2">
                                <a href="alat_edit.php?id=<?= $row['id_alat'] ?>" class="w-10 h-10 rounded-xl border border-blue-100 flex items-center justify-center text-blue-500 hover:bg-blue-600 hover:text-white transition-all shadow-sm">
                                    <i class="fas fa-edit text-xs"></i>
                                </a>
                                <a href="alat_hapus.php?id=<?= $row['id_alat'] ?>" onclick="return confirm('Hapus alat ini?')" class="w-10 h-10 rounded-xl border border-red-100 flex items-center justify-center text-red-400 hover:bg-red-500 hover:text-white transition-all shadow-sm">
                                    <i class="fas fa-trash text-xs"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>