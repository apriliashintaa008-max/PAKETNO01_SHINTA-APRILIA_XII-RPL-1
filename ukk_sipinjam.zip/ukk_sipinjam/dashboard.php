<?php
session_start();
include 'config/koneksi.php';
if (!isset($_SESSION['login'])) { header("Location: auth/login.php"); exit; }

// --- BAGIAN LOGIKA STATISTIK (DIPERBAIKI) ---
// Total User
$q_user = mysqli_query($conn, "SELECT COUNT(*) as total FROM tb_user");
$total_user = ($q_user) ? mysqli_fetch_assoc($q_user)['total'] : 0;

// Total Alat
$q_alat = mysqli_query($conn, "SELECT COUNT(*) as total FROM tb_alat");
$total_alat = ($q_alat) ? mysqli_fetch_assoc($q_alat)['total'] : 0;

// Menunggu Persetujuan
$q_menunggu = mysqli_query($conn, "SELECT COUNT(*) as total FROM tb_peminjaman WHERE status='Menunggu'");
$menunggu = ($q_menunggu) ? mysqli_fetch_assoc($q_menunggu)['total'] : 0;

// Terlambat Kembali
$q_terlambat = mysqli_query($conn, "SELECT COUNT(*) as total FROM tb_peminjaman WHERE status='Disetujui' AND tgl_kembali < CURDATE()");
$terlambat = ($q_terlambat) ? mysqli_fetch_assoc($q_terlambat)['total'] : 0;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - SIPINJAM</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>body { font-family: 'Plus Jakarta Sans', sans-serif; }</style>
</head>
<body class="bg-[#F4F7FE] flex h-screen overflow-hidden">

    <aside class="w-72 bg-[#0B1437] text-white flex flex-col p-8">
        <div class="flex items-center gap-3 mb-10">
            <i class="fas fa-clipboard-list text-2xl text-blue-500"></i>
            <h1 class="text-xl font-black tracking-tighter uppercase">SIPINJAM</h1>
        </div>
        <nav class="space-y-1 flex-1 overflow-y-auto pr-2">
            <a href="dashboard.php" class="flex items-center gap-4 bg-blue-600 p-4 rounded-2xl font-bold mb-4 shadow-lg shadow-blue-900/20">
                <i class="fas fa-home"></i> Dashboard
            </a>
            
            <p class="text-[10px] text-gray-500 font-black uppercase tracking-widest pt-4 pb-2">Master</p>
            <a href="user.php" class="flex items-center gap-4 p-4 text-gray-400 hover:text-white transition-all font-semibold">
                <i class="fas fa-user"></i> User
            </a>
            <a href="alat.php" class="flex items-center gap-4 p-4 text-gray-400 hover:text-white transition-all font-semibold">
                <i class="fas fa-tools"></i> Alat
            </a>
            <a href="kategori.php" class="flex items-center gap-4 p-4 text-gray-400 hover:text-white transition-all font-semibold">
                <i class="fas fa-tags"></i> Kategori
            </a>

            <p class="text-[10px] text-gray-500 font-black uppercase tracking-widest pt-6 pb-2">Transaksi</p>
            <a href="peminjaman.php" class="flex items-center gap-4 p-4 text-gray-400 hover:text-white transition-all font-semibold">
                <i class="fas fa-receipt"></i> Peminjaman
            </a>
            <a href="pengembalian.php" class="flex items-center gap-4 p-4 text-gray-400 hover:text-white transition-all font-semibold">
                <i class="fas fa-undo"></i> Pengembalian
            </a>

            <p class="text-[10px] text-gray-500 font-black uppercase tracking-widest pt-6 pb-2">Laporan</p>
            <a href="laporan.php" class="flex items-center gap-4 p-4 text-gray-400 hover:text-white transition-all font-semibold">
                <i class="fas fa-file-alt"></i> Laporan
            </a>
            <a href="log.php" class="flex items-center gap-4 p-4 text-gray-400 hover:text-white transition-all font-semibold">
                <i class="fas fa-history"></i> Log Aktivitas
            </a>

            <a href="auth/logout.php" class="flex items-center gap-4 p-4 text-red-400 font-bold mt-10 hover:bg-red-500/10 rounded-2xl transition-all">
                <i class="fas fa-sign-out-alt"></i> Keluar
            </a>
        </nav>
    </aside>

    <main class="flex-1 p-10 overflow-y-auto">
        <header class="flex justify-between items-center mb-10">
            <h2 class="text-3xl font-black text-[#1B2559]">Dashboard</h2>
            <div class="flex items-center gap-4 bg-white p-3 rounded-2xl shadow-sm border border-gray-100">
                <div class="text-right">
                    <p class="text-xs font-black text-[#1B2559]"><?= $_SESSION['nama'] ?></p>
                    <p class="text-[10px] text-gray-400 font-bold uppercase"><?= $_SESSION['role'] ?></p>
                </div>
                <img src="https://ui-avatars.com/api/?name=<?= $_SESSION['nama'] ?>&background=4318FF&color=fff" class="w-10 h-10 rounded-xl" alt="profile">
            </div>
        </header>

        <div class="grid grid-cols-4 gap-6 mb-10">
            <div class="bg-white p-6 rounded-[2.5rem] shadow-sm flex items-center gap-5 border border-gray-50">
                <div class="w-14 h-14 bg-blue-50 text-blue-500 rounded-2xl flex items-center justify-center text-xl"><i class="fas fa-users"></i></div>
                <div><p class="text-2xl font-black text-[#1B2559]"><?= $total_user ?></p><p class="text-[10px] font-bold text-gray-400 uppercase">Total User</p></div>
            </div>
            <div class="bg-white p-6 rounded-[2.5rem] shadow-sm flex items-center gap-5 border border-gray-50">
                <div class="w-14 h-14 bg-green-50 text-green-500 rounded-2xl flex items-center justify-center text-xl"><i class="fas fa-tools"></i></div>
                <div><p class="text-2xl font-black text-[#1B2559]"><?= $total_alat ?></p><p class="text-[10px] font-bold text-gray-400 uppercase">Total Alat</p></div>
            </div>
            <div class="bg-white p-6 rounded-[2.5rem] shadow-sm flex items-center gap-5 border border-gray-50">
                <div class="w-14 h-14 bg-orange-50 text-orange-500 rounded-2xl flex items-center justify-center text-xl"><i class="fas fa-clock"></i></div>
                <div><p class="text-2xl font-black text-[#1B2559]"><?= $menunggu ?></p><p class="text-[10px] font-bold text-gray-400 uppercase leading-tight">Menunggu Persetujuan</p></div>
            </div>
            <div class="bg-white p-6 rounded-[2.5rem] shadow-sm flex items-center gap-5 border border-gray-50">
                <div class="w-14 h-14 bg-red-50 text-red-500 rounded-2xl flex items-center justify-center text-xl"><i class="fas fa-calendar-times"></i></div>
                <div><p class="text-2xl font-black text-[#1B2559]"><?= $terlambat ?></p><p class="text-[10px] font-bold text-gray-400 uppercase leading-tight">Terlambat Kembali</p></div>
            </div>
        </div>

        <div class="grid grid-cols-3 gap-6">
            <div class="col-span-2 bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-50">
                <div class="flex justify-between items-center mb-8">
                    <h3 class="text-xl font-black text-[#1B2559]">Peminjaman Terbaru</h3>
                    <a href="peminjaman.php" class="text-blue-600 text-xs font-bold hover:underline">Lihat Semua</a>
                </div>
                <div class="space-y-6">
                    <?php
                    $q_pinjam = mysqli_query($conn, "SELECT p.*, u.nama, a.nama_alat FROM tb_peminjaman p 
                                JOIN tb_user u ON p.id_user = u.id_user 
                                JOIN tb_alat a ON p.id_alat = a.id_alat 
                                ORDER BY p.id_peminjaman DESC LIMIT 3");
                    if($q_pinjam && mysqli_num_rows($q_pinjam) > 0) {
                        while($row = mysqli_fetch_assoc($q_pinjam)):
                            $status_color = ($row['status'] == 'Disetujui') ? 'bg-green-100 text-green-600' : 
                                            (($row['status'] == 'Kembali') ? 'bg-blue-100 text-blue-600' : 'bg-orange-100 text-orange-600');
                    ?>
                    <div class="flex items-center justify-between p-2 hover:bg-gray-50 rounded-2xl transition-all">
                        <div class="flex items-center gap-4">
                            <img src="https://ui-avatars.com/api/?name=<?= urlencode($row['nama']) ?>&background=random" class="w-12 h-12 rounded-full border-2 border-white shadow-sm">
                            <div>
                                <p class="text-sm font-black text-[#1B2559]"><?= $row['nama'] ?></p>
                                <p class="text-xs text-gray-400 font-semibold"><?= $row['nama_alat'] ?></p>
                            </div>
                        </div>
                        <div class="text-right">
                            <p class="text-[10px] font-bold text-gray-300 mb-1 uppercase tracking-wider"><?= date('d M Y', strtotime($row['tgl_pinjam'])) ?></p>
                            <span class="px-4 py-1.5 <?= $status_color ?> text-[10px] font-extrabold rounded-xl uppercase tracking-tighter italic shadow-sm"><?= $row['status'] ?></span>
                        </div>
                    </div>
                    <?php endwhile; } else { echo "<p class='text-gray-400 text-sm italic'>Belum ada data peminjaman.</p>"; } ?>
                </div>
            </div>

            <div class="bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-50">
                <h3 class="text-xl font-black text-[#1B2559] mb-8">Alat Stok Rendah</h3>
                <div class="space-y-6">
                    <?php
                    $q_stok = mysqli_query($conn, "SELECT * FROM tb_alat WHERE stok < 5 ORDER BY stok ASC LIMIT 4");
                    if($q_stok && mysqli_num_rows($q_stok) > 0) {
                        while($alat = mysqli_fetch_assoc($q_stok)):
                    ?>
                    <div class="flex items-center gap-4 p-2 hover:bg-gray-50 rounded-2xl transition-all">
                        <div class="w-12 h-12 bg-gray-50 text-[#1B2559] rounded-2xl flex items-center justify-center text-lg shadow-inner"><i class="fas fa-tools"></i></div>
                        <div>
                            <p class="text-sm font-black text-[#1B2559]"><?= $alat['nama_alat'] ?></p>
                            <div class="flex items-center gap-2 mt-1">
                                <span class="w-2 h-2 rounded-full bg-orange-500 animate-pulse"></span>
                                <p class="text-xs font-bold text-orange-500 italic">Stok: <?= $alat['stok'] ?></p>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; } else { echo "<p class='text-gray-400 text-sm italic'>Semua stok alat aman.</p>"; } ?>
                </div>
            </div>
        </div>
    </main>

</body>
</html>