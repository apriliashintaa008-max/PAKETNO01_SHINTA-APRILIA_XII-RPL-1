<?php
session_start();
include 'config/koneksi.php';
if (!isset($_SESSION['login'])) { header("Location: login.php"); exit; }

$data_pinjam = null;
$id_cari = "";

// --- LOGIKA CARI ID PEMINJAMAN ---
if (isset($_POST['cari_id'])) {
    $id_cari = $_POST['id_peminjaman'];
    $query = mysqli_query($conn, "SELECT p.*, u.nama, a.nama_alat FROM tb_peminjaman p 
             JOIN tb_user u ON p.id_user = u.id_user 
             JOIN tb_alat a ON p.id_alat = a.id_alat 
             WHERE p.id_peminjaman = '$id_cari' AND p.status = 'Disetujui'");
    $data_pinjam = mysqli_fetch_assoc($query);
    
    if (!$data_pinjam) {
        echo "<script>alert('ID Peminjaman tidak ditemukan atau belum disetujui!');</script>";
    }
}

// --- LOGIKA SIMPAN PENGEMBALIAN ---
if (isset($_POST['simpan_kembali'])) {
    $id_p = $_POST['id_p_proses'];
    $tgl_kembali = $_POST['tgl_kembali'];
    $denda = $_POST['denda'];
    
    // Update status peminjaman & insert ke tabel pengembalian
    mysqli_query($conn, "UPDATE tb_peminjaman SET status='Kembali' WHERE id_peminjaman='$id_p'");
    mysqli_query($conn, "INSERT INTO tb_pengembalian (id_peminjaman, tgl_kembali, denda) VALUES ('$id_p', '$tgl_kembali', '$denda')");
    
    echo "<script>alert('Data pengembalian berhasil disimpan!'); window.location='pengembalian.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Pengembalian - SIPINJAM</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>body { font-family: 'Plus Jakarta Sans', sans-serif; }</style>
</head>
<body class="bg-[#F4F7FE] flex h-screen overflow-hidden">

    <aside class="w-72 bg-[#0B1437] text-white flex flex-col p-8">
        <div class="flex items-center gap-3 mb-10">
            <i class="fas fa-clipboard-list text-2xl text-blue-500"></i>
            <h1 class="text-xl font-black tracking-tighter uppercase">SIPINJAM</h1>
        </div>
        <nav class="space-y-1 flex-1 overflow-y-auto pr-2">
            <a href="dashboard.php" class="flex items-center gap-4 p-4 text-gray-400 hover:text-white transition-all font-semibold mb-4">
                <i class="fas fa-home"></i> Dashboard
            </a>
            <p class="text-[10px] text-gray-500 font-black uppercase tracking-widest pt-4 pb-2">Transaksi</p>
            <a href="peminjaman.php" class="flex items-center gap-4 p-4 text-gray-400 hover:text-white transition-all font-semibold">
                <i class="fas fa-receipt"></i> Peminjaman
            </a>
            <a href="pengembalian.php" class="flex items-center gap-4 bg-blue-600 p-4 rounded-2xl font-bold text-white shadow-lg shadow-blue-900/20">
                <i class="fas fa-undo"></i> Pengembalian
            </a>
        </nav>
    </aside>

    <main class="flex-1 p-10 overflow-y-auto">
        <h2 class="text-3xl font-black text-[#1B2559] mb-10">Input Pengembalian</h2>

        <div class="max-w-2xl bg-white p-10 rounded-[2.5rem] shadow-sm border border-gray-50">
            <form action="" method="POST" class="mb-8">
                <label class="block text-sm font-bold text-[#1B2559] mb-2">ID Peminjaman</label>
                <div class="flex gap-3">
                    <input type="text" name="id_peminjaman" value="<?= $id_cari ?>" placeholder="Contoh: PMJ001" required class="flex-1 bg-gray-50 border border-gray-100 p-4 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <button type="submit" name="cari_id" class="bg-blue-600 text-white px-8 rounded-2xl font-bold hover:bg-blue-700 transition-all">Cari</button>
                </div>
            </form>

            <?php if ($data_pinjam): ?>
            <div class="bg-blue-50/50 p-6 rounded-[2rem] mb-8 border border-blue-100/50">
                <div class="space-y-2 text-sm">
                    <p class="text-gray-500 font-medium">Peminjam: <span class="text-[#1B2559] font-bold"><?= $data_pinjam['nama'] ?></span></p>
                    <p class="text-gray-500 font-medium">Alat: <span class="text-[#1B2559] font-bold"><?= $data_pinjam['nama_alat'] ?></span></p>
                    <p class="text-gray-500 font-medium">Tanggal Pinjam: <span class="text-[#1B2559] font-bold"><?= date('d-m-Y', strtotime($data_pinjam['tgl_pinjam'])) ?></span></p>
                </div>
            </div>

            <form action="" method="POST" class="space-y-6">
                <input type="hidden" name="id_p_proses" value="<?= $data_pinjam['id_peminjaman'] ?>">
                
                <div>
                    <label class="block text-sm font-bold text-[#1B2559] mb-2">Tanggal Kembali</label>
                    <input type="date" name="tgl_kembali" required class="w-full bg-gray-50 border border-gray-100 p-4 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>

                <div>
                    <label class="block text-sm font-bold text-[#1B2559] mb-2">Denda</label>
                    <input type="text" name="denda" placeholder="Rp 0" class="w-full bg-gray-50 border border-gray-100 p-4 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <p class="text-[10px] text-gray-400 mt-2 ml-2 italic">*Kosongkan jika tidak ada denda</p>
                </div>

                <div class="flex gap-4 pt-4">
                    <button type="button" onclick="window.location.reload()" class="flex-1 bg-gray-100 text-gray-500 font-bold py-4 rounded-2xl hover:bg-gray-200 transition-all">Batal</button>
                    <button type="submit" name="simpan_kembali" class="flex-1 bg-[#059669] text-white font-bold py-4 rounded-2xl shadow-lg shadow-green-100 hover:scale-105 transition-all">Simpan Pengembalian</button>
                </div>
            </form>
            <?php endif; ?>
        </div>
    </main>
</body>
</html>