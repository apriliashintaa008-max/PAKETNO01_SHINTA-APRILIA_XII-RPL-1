<?php
session_start();
include 'config/koneksi.php';
if (!isset($_SESSION['login'])) { header("Location: login.php"); exit; }

// --- LOGIKA UPDATE DATA ---
if (isset($_POST['update_inline'])) {
    $id_user = $_POST['id_user'];
    $nama = $_POST['nama'];
    $username = $_POST['username'];
    $role = $_POST['role'];

    $update = mysqli_query($conn, "UPDATE tb_user SET nama='$nama', username='$username', role='$role' WHERE id_user='$id_user'");
    if ($update) {
        echo "<script>alert('Data berhasil diupdate!'); window.location='user.php';</script>";
    }
}

$keyword = "";
if (isset($_POST['cari'])) {
    $keyword = $_POST['keyword'];
    $query = mysqli_query($conn, "SELECT * FROM tb_user WHERE nama LIKE '%$keyword%' OR username LIKE '%$keyword%' ORDER BY id_user DESC");
} else {
    $query = mysqli_query($conn, "SELECT * FROM tb_user ORDER BY id_user DESC");
}

// Cek apakah sedang dalam mode edit untuk baris tertentu
$edit_id = isset($_GET['edit_id']) ? $_GET['edit_id'] : null;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data User - SIPINJAM</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>body { font-family: 'Plus Jakarta Sans', sans-serif; }</style>
</head>
<body class="bg-[#F4F7FE] flex h-screen overflow-hidden">

    <aside class="w-72 bg-[#0B1437] text-white flex flex-col p-8">
        <div class="flex items-center gap-3 mb-10">
            <i class="fas fa-clipboard-list text-2xl text-blue-500"></i>
            <h1 class="text-xl font-black tracking-tighter uppercase">SIPINJAM</h1>
        </div>
        <nav class="space-y-1 flex-1 overflow-y-auto pr-2">
            <a href="dashboard.php" class="flex items-center gap-4 p-4 text-gray-400 hover:text-white transition-all font-semibold mb-4">
                <i class="fas fa-home"></i> Dashboard
            </a>
            <p class="text-[10px] text-gray-500 font-black uppercase tracking-widest pt-4 pb-2">Master</p>
            <a href="user.php" class="flex items-center gap-4 bg-blue-600 p-4 rounded-2xl font-bold text-white shadow-lg shadow-blue-900/20">
                <i class="fas fa-user"></i> User
            </a>
            <a href="alat.php" class="flex items-center gap-4 p-4 text-gray-400 hover:text-white transition-all font-semibold"><i class="fas fa-tools"></i> Alat</a>
            <a href="kategori.php" class="flex items-center gap-4 p-4 text-gray-400 hover:text-white transition-all font-semibold"><i class="fas fa-tags"></i> Kategori</a>
        </nav>
    </aside>

    <main class="flex-1 p-10 overflow-y-auto">
        <div class="flex justify-between items-center mb-10">
            <h2 class="text-3xl font-black text-[#1B2559]">Data User</h2>
            <button onclick="location.href='user_tambah.php'" class="bg-[#4318FF] text-white px-6 py-3 rounded-2xl font-bold flex items-center gap-2 shadow-lg shadow-blue-200 hover:scale-105 transition-all">
                <i class="fas fa-plus"></i> Tambah User
            </button>
        </div>

        <div class="mb-8">
            <form action="" method="POST" class="relative max-w-sm">
                <input type="text" name="keyword" value="<?= $keyword ?>" placeholder="Cari user..." class="w-full bg-white pl-12 pr-4 py-4 rounded-3xl text-sm focus:outline-none shadow-sm border border-gray-50">
                <i class="fas fa-search absolute left-5 top-1/2 -translate-y-1/2 text-gray-300"></i>
                <button type="submit" name="cari" class="hidden"></button>
            </form>
        </div>

        <div class="bg-white rounded-[2.5rem] p-8 shadow-sm border border-gray-50">
            <table class="w-full text-left">
                <thead>
                    <tr class="text-gray-400 text-[13px] font-bold uppercase tracking-widest border-b border-gray-100">
                        <th class="pb-6 pl-4">No</th>
                        <th class="pb-6">Username</th>
                        <th class="pb-6">Nama</th>
                        <th class="pb-6">Role</th>
                        <th class="pb-6 pr-4 text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    <?php 
                    $no = 1;
                    while($row = mysqli_fetch_assoc($query)): 
                        // Cek apakah baris ini sedang di-edit
                        if($edit_id == $row['id_user']):
                    ?>
                        <form action="" method="POST">
                            <input type="hidden" name="id_user" value="<?= $row['id_user'] ?>">
                            <tr class="bg-blue-50/50">
                                <td class="py-6 pl-4 font-bold text-[#1B2559] text-sm"><?= $no++ ?></td>
                                <td class="py-4">
                                    <input type="text" name="username" value="<?= $row['username'] ?>" class="bg-white border border-blue-200 p-2 rounded-lg text-sm w-full focus:ring-2 focus:ring-blue-500 outline-none">
                                </td>
                                <td class="py-4">
                                    <input type="text" name="nama" value="<?= $row['nama'] ?>" class="bg-white border border-blue-200 p-2 rounded-lg text-sm w-full focus:ring-2 focus:ring-blue-500 outline-none">
                                </td>
                                <td class="py-4">
                                    <select name="role" class="bg-white border border-blue-200 p-2 rounded-lg text-sm w-full focus:ring-2 focus:ring-blue-500 outline-none font-bold italic uppercase">
                                        <option value="admin" <?= $row['role'] == 'admin' ? 'selected' : '' ?>>admin</option>
                                        <option value="petugas" <?= $row['role'] == 'petugas' ? 'selected' : '' ?>>petugas</option>
                                        <option value="peminjam" <?= $row['role'] == 'peminjam' ? 'selected' : '' ?>>peminjam</option>
                                    </select>
                                </td>
                                <td class="py-4 pr-4">
                                    <div class="flex justify-center gap-2">
                                        <button type="submit" name="update_inline" class="bg-green-500 text-white w-10 h-10 rounded-xl flex items-center justify-center hover:bg-green-600 shadow-sm transition-all">
                                            <i class="fas fa-check text-xs"></i>
                                        </button>
                                        <a href="user.php" class="bg-gray-400 text-white w-10 h-10 rounded-xl flex items-center justify-center hover:bg-gray-500 shadow-sm transition-all">
                                            <i class="fas fa-times text-xs"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        </form>
                    <?php else: 
                        $badge = "bg-blue-100 text-blue-500";
                        if($row['role'] == 'petugas') $badge = "bg-indigo-100 text-indigo-500";
                        if($row['role'] == 'peminjam') $badge = "bg-green-100 text-green-500";
                    ?>
                        <tr class="hover:bg-gray-50/50 transition-all group">
                            <td class="py-6 pl-4 font-bold text-[#1B2559] text-sm"><?= $no++ ?></td>
                            <td class="py-6 text-sm font-semibold text-gray-500"><?= $row['username'] ?></td>
                            <td class="py-6 text-sm font-bold text-[#1B2559]"><?= $row['nama'] ?></td>
                            <td class="py-6">
                                <span class="px-4 py-1.5 <?= $badge ?> rounded-full text-[11px] font-black uppercase tracking-tighter italic">
                                    <?= $row['role'] ?>
                                </span>
                            </td>
                            <td class="py-6 pr-4">
                                <div class="flex justify-center gap-2">
                                    <a href="user.php?edit_id=<?= $row['id_user'] ?>" class="w-10 h-10 rounded-xl border border-blue-100 flex items-center justify-center text-blue-500 hover:bg-blue-600 hover:text-white transition-all shadow-sm">
                                        <i class="fas fa-edit text-xs"></i>
                                    </a>
                                    <a href="user_hapus.php?id=<?= $row['id_user'] ?>" onclick="return confirm('Hapus user ini?')" class="w-10 h-10 rounded-xl border border-red-100 flex items-center justify-center text-red-400 hover:bg-red-500 hover:text-white transition-all shadow-sm">
                                        <i class="fas fa-trash text-xs"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endif; endwhile; ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>