<?php
session_start();
include 'config/koneksi.php'; // Pastikan path benar jika file ini di dalam folder auth/

// LOGIKA PROSES LOGIN
if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];
    $role     = $_POST['role'];

    // Query cek user berdasarkan username dan role (Sesuaikan nama tabel: tb_user)
    $query = mysqli_query($conn, "SELECT * FROM tb_user WHERE username='$username' AND role='$role'");
    $data  = mysqli_fetch_assoc($query);

    // Verifikasi Password 
    // Diubah menjadi perbandingan string biasa (==) karena password di database kamu bukan hash
    if ($data && $password == $data['password']) {
        
        $_SESSION['login']        = true;
        $_SESSION['id_user']      = $data['id_user'];
        $_SESSION['username']     = $data['username'];
        $_SESSION['nama']         = $data['nama']; // Sesuaikan dengan kolom 'nama' di database kamu
        $_SESSION['role']         = $data['role'];

        // Redirect ke dashboard
        header("Location: dashboard.php");
        exit;
    } else {
        $error = "Username, Password, atau Role salah!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - SIPINJAM</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        body { background-color: #F4F7FE; font-family: 'Plus Jakarta Sans', sans-serif; height: 100vh; display: flex; align-items: center; }
        .login-card { border-radius: 40px; overflow: hidden; border: none; box-shadow: 0 20px 40px rgba(0,0,0,0.05); background: white; min-height: 550px; }
        .brand-side { background: white; padding: 60px; display: flex; flex-direction: column; align-items: center; justify-content: center; }
        .form-side { background: #F4F7FE; padding: 60px; display: flex; flex-direction: column; justify-content: center; }
        .btn-navy { background: #0B1437; color: white; border-radius: 15px; padding: 12px; font-weight: bold; width: 100%; border: none; }
        .btn-navy:hover { background: #1b2559; color: white; }
        .form-control, .form-select { border-radius: 15px; padding: 12px 20px; border: none; background: white; font-weight: 600; color: #2B3674; }
        .form-label { font-weight: bold; color: #2B3674; margin-left: 5px; font-size: 14px; }
        .text-navy { color: #0B1437; }
        .italic { font-style: italic; }
    </style>
</head>
<body>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="card login-card flex-md-row">
                
                <div class="col-md-6 brand-side text-center">
                    <div class="mb-4">
                        <i class="fas fa-clipboard-list fa-5x text-primary"></i>
                    </div>
                    <h2 class="fw-bold italic text-navy">SIPINJAM</h2>
                    <p class="text-secondary fw-semibold">Sistem Informasi Peminjaman Alat</p>
                </div>

                <div class="col-md-6 form-side">
                    <h3 class="fw-bold mb-4" style="color: #2B3674;">Login</h3>

                    <?php if (isset($error)): ?>
                        <div class="alert alert-danger rounded-4 py-2 small fw-bold mb-3 border-0 shadow-sm">
                            <i class="fas fa-exclamation-circle me-2"></i> <?= $error ?>
                        </div>
                    <?php endif; ?>

                    <form action="" method="POST">
                        <div class="mb-3">
                            <label class="form-label">Username</label>
                            <input type="text" name="username" class="form-control shadow-sm" placeholder="Masukkan username" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" name="password" class="form-control shadow-sm" placeholder="Masukkan password" required>
                        </div>
                        <div class="mb-4">
                            <label class="form-label">Role</label>
                            <select name="role" class="form-select shadow-sm" required>
                                <option value="peminjam">Peminjam</option>
                                <option value="petugas">Petugas</option>
                                <option value="admin">Admin</option>
                            </select>
                        </div>
                        <button type="submit" name="login" class="btn btn-navy shadow">LOGIN</button>
                    </form>
                    
                    <div class="mt-4 text-center">
                        <small class="text-secondary fw-bold">UKK Rekayasa Perangkat Lunak 2026</small>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>