<?php
session_start();
include 'config/koneksi.php';
if (!isset($_SESSION['login'])) { header("Location: login.php"); exit; }
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Log Aktivitas - SIPINJAM</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>body { font-family: 'Plus Jakarta Sans', sans-serif; }</style>
</head>
<body class="bg-[#F4F7FE] flex h-screen overflow-hidden">
    <main class="flex-1 p-10 overflow-y-auto">
        <h2 class="text-3xl font-black text-[#1B2559] mb-10">Log Aktivitas Sistem</h2>

        <div class="bg-white rounded-[2.5rem] p-8 shadow-sm border border-gray-50">
            <div class="space-y-6 relative before:absolute before:inset-0 before:left-8 before:w-0.5 before:bg-gray-100">
                <?php 
                // Mengambil data dari tb_log
                $logs = mysqli_query($conn, "SELECT * FROM tb_log ORDER BY id_log DESC LIMIT 20");
                while($l = mysqli_fetch_assoc($logs)):
                ?>
                <div class="relative pl-16">
                    <div class="absolute left-6 top-1.5 w-4 h-4 rounded-full bg-blue-600 border-4 border-white shadow-sm shadow-blue-200"></div>
                    <p class="text-[11px] font-black text-blue-600 uppercase tracking-widest mb-1"><?= date('d M Y | H:i', strtotime($l['waktu'])) ?></p>
                    <div class="bg-gray-50/50 p-4 rounded-2xl border border-gray-100">
                        <p class="text-sm font-semibold text-[#1B2559]"><?= $l['aksi'] ?></p>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
    </main>
</body>
</html>