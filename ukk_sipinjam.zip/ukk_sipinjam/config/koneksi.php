<?php
$conn = mysqli_connect("localhost", "root", "", "ukk_sipinjam");

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>