<?php
session_start();
if (!isset($_SESSION['login'])) { header("Location: login.php"); exit; }
include 'config/koneksi.php';
$role = $_SESSION['role'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <title>SIPINJAM - Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background-color: #F4F7FE; font-family: 'Plus Jakarta Sans', sans-serif; }
    </style>
</head>
<body class="flex">

    <aside class="w-72 bg-[#001b3d] min-h-screen p-6 text-white fixed">
        <div class="flex items-center gap-3 mb-10 px-2">
            <i class="fas fa-file-signature text-2xl text-blue-500"></i>
            <h1 class="text-xl font-bold uppercase tracking-tight">SIPINJAM</h1>
        </div>

        <nav class="space-y-2">
            <a href="?page=dashboard" class="flex items-center gap-3 px-4 py-3 rounded-2xl bg-blue-600 font-bold">
                <i class="fas fa-th-large w-5"></i> Dashboard
            </a>

            <?php if ($role == 'admin') : ?>
                <div class="pt-6 pb-2 px-4 text-[10px] text-gray-400 font-bold uppercase tracking-widest">Master</div>
                <a href="?page=user" class="flex items-center gap-3 px-4 py-3 rounded-2xl hover:bg-white/5 transition"><i class="fas fa-user w-5"></i> User</a>
                <a href="?page=alat" class="flex items-center gap-3 px-4 py-3 rounded-2xl hover:bg-white/5 transition"><i class="fas fa-tools w-5"></i> Alat</a>
                <a href="?page=kategori" class="flex items-center gap-3 px-4 py-3 rounded-2xl hover:bg-white/5 transition"><i class="fas fa-layer-group w-5"></i> Kategori</a>
                
                <div class="pt-6 pb-2 px-4 text-[10px] text-gray-400 font-bold uppercase tracking-widest">Laporan</div>
                <a href="?page=log" class="flex items-center gap-3 px-4 py-3 rounded-2xl hover:bg-white/5 transition"><i class="fas fa-history w-5"></i> Log Aktivitas</a>
            <?php endif; ?>

            <?php if ($role == 'petugas' || $role == 'admin') : ?>
                <div class="pt-6 pb-2 px-4 text-[10px] text-gray-400 font-bold uppercase tracking-widest">Transaksi</div>
                <a href="?page=peminjaman" class="flex items-center gap-3 px-4 py-3 rounded-2xl hover:bg-white/5 transition"><i class="fas fa-check-circle w-5"></i> Persetujuan</a>
                <a href="?page=pengembalian" class="flex items-center gap-3 px-4 py-3 rounded-2xl hover:bg-white/5 transition"><i class="fas fa-undo w-5"></i> Pengembalian</a>
            <?php endif; ?>

            <?php if ($role == 'peminjam') : ?>
                <div class="pt-6 pb-2 px-4 text-[10px] text-gray-400 font-bold uppercase tracking-widest">Peminjam</div>
                <a href="?page=daftar-alat" class="flex items-center gap-3 px-4 py-3 rounded-2xl hover:bg-white/5 transition"><i class="fas fa-list w-5"></i> Daftar Alat</a>
                <a href="?page=ajukan-pinjam" class="flex items-center gap-3 px-4 py-3 rounded-2xl hover:bg-white/5 transition"><i class="fas fa-plus-circle w-5"></i> Ajukan Peminjaman</a>
            <?php endif; ?>

            <a href="logout.php" class="flex items-center gap-3 px-4 py-3 mt-10 rounded-2xl text-red-400 hover:bg-red-500/10 transition">
                <i class="fas fa-sign-out-alt w-5"></i> Logout
            </a>
        </nav>
    </aside>

    <main class="flex-1 ml-72 p-10">
        <?php
        $page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';
        include "pages/$page.php"; // File-file CRUD ditaruh di folder 'pages'
        ?>
    </main>

</body>
</html>