<?php
session_start();
include 'config/koneksi.php';
if (!isset($_SESSION['login'])) { header("Location: login.php"); exit; }
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan - SIPINJAM</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>body { font-family: 'Plus Jakarta Sans', sans-serif; }</style>
</head>
<body class="bg-[#F4F7FE] flex h-screen overflow-hidden">
    <aside class="w-72 bg-[#0B1437] text-white flex flex-col p-8">
        <div class="flex items-center gap-3 mb-10">
            <i class="fas fa-clipboard-list text-2xl text-blue-500"></i>
            <h1 class="text-xl font-black uppercase tracking-tighter">SIPINJAM</h1>
        </div>
        <nav class="space-y-1 flex-1">
            <a href="dashboard.php" class="flex items-center gap-4 p-4 text-gray-400 hover:text-white font-semibold mb-4"><i class="fas fa-home"></i> Dashboard</a>
            <p class="text-[10px] text-gray-500 font-black uppercase tracking-widest pt-4 pb-2">Laporan</p>
            <a href="laporan.php" class="flex items-center gap-4 bg-blue-600 p-4 rounded-2xl font-bold text-white shadow-lg shadow-blue-900/20"><i class="fas fa-file-alt"></i> Laporan</a>
            <a href="log.php" class="flex items-center gap-4 p-4 text-gray-400 hover:text-white font-semibold"><i class="fas fa-history"></i> Log Aktivitas</a>
        </nav>
    </aside>

    <main class="flex-1 p-10 overflow-y-auto">
        <div class="flex justify-between items-center mb-10">
            <h2 class="text-3xl font-black text-[#1B2559]">Laporan Transaksi</h2>
            <button onclick="window.print()" class="bg-white text-blue-600 border border-blue-100 px-6 py-3 rounded-2xl font-bold flex items-center gap-2 shadow-sm hover:bg-blue-50 transition-all">
                <i class="fas fa-print"></i> Cetak PDF
            </button>
        </div>

        <div class="bg-white rounded-[2.5rem] p-8 shadow-sm border border-gray-50">
            <table class="w-full text-left">
                <thead>
                    <tr class="text-gray-400 text-[11px] font-black uppercase tracking-widest border-b border-gray-100">
                        <th class="pb-6 pl-4">ID</th>
                        <th class="pb-6">Peminjam</th>
                        <th class="pb-6">Alat</th>
                        <th class="pb-6">Tgl Pinjam</th>
                        <th class="pb-6">Tgl Kembali</th>
                        <th class="pb-6">Denda</th>
                        <th class="pb-6">Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    <?php 
                    // Query dengan proteksi jika tb_pengembalian belum ada
                    $sql = "SELECT p.*, u.nama, a.nama_alat, k.tgl_kembali, k.denda 
                            FROM tb_peminjaman p 
                            JOIN tb_user u ON p.id_user = u.id_user 
                            JOIN tb_alat a ON p.id_alat = a.id_alat 
                            LEFT JOIN tb_pengembalian k ON p.id_peminjaman = k.id_peminjaman 
                            ORDER BY p.id_peminjaman DESC";
                    
                    $q = mysqli_query($conn, $sql);

                    if ($q): // Hanya jalankan loop jika query berhasil
                        while($row = mysqli_fetch_assoc($q)): 
                            $status_color = ($row['status'] == 'Kembali') ? 'text-green-500 bg-green-50' : 'text-orange-500 bg-orange-50';
                    ?>
                    <tr class="text-sm hover:bg-gray-50/50">
                        <td class="py-6 pl-4 font-bold text-gray-400"><?= $row['id_peminjaman'] ?></td>
                        <td class="py-6 font-bold text-[#1B2559]"><?= $row['nama'] ?></td>
                        <td class="py-6 text-gray-500"><?= $row['nama_alat'] ?></td>
                        <td class="py-6 text-gray-500"><?= date('d/m/y', strtotime($row['tgl_pinjam'])) ?></td>
                        <td class="py-6 text-gray-500"><?= ($row['tgl_kembali']) ? date('d/m/y', strtotime($row['tgl_kembali'])) : '-' ?></td>
                        <td class="py-6 font-bold text-red-500">Rp <?= number_format($row['denda'] ?? 0, 0, ',', '.') ?></td>
                        <td class="py-6">
                            <span class="px-4 py-1 rounded-xl text-[10px] font-black uppercase <?= $status_color ?>">
                                <?= $row['status'] ?>
                            </span>
                        </td>
                    </tr>
                    <?php 
                        endwhile; 
                    else:
                        // Pesan bantuan jika query gagal
                        echo "<tr><td colspan='7' class='py-10 text-center text-red-500 font-bold italic'>Gagal mengambil data. Pastikan tabel 'tb_pengembalian' sudah ada di database.</td></tr>";
                    endif; 
                    ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>