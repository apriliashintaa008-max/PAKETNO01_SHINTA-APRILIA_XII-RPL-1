<header class="bg-white p-4 shadow-sm border-b border-slate-100 flex justify-between items-center sticky top-0 z-10">
    <div class="flex items-center gap-4">
        <button class="md:hidden text-slate-500 hover:text-blue-600 transition">
            <i class="fas fa-bars text-xl"></i>
        </button>
        
        <div class="hidden md:block">
            <h2 class="text-sm font-medium text-slate-400">Selamat Datang,</h2>
            <p class="text-base font-bold text-[#2B3674]"><?= $_SESSION['nama']; ?> <span class="text-[10px] bg-blue-100 text-blue-600 px-2 py-0.5 rounded-full ml-1 uppercase font-extrabold"><?= $_SESSION['role']; ?></span></p>
        </div>
    </div>
    
    <div class="flex items-center gap-6">
        <div class="hidden lg:flex items-center bg-slate-50 px-4 py-2 rounded-xl border border-slate-100">
            <i class="fas fa-search text-slate-400 text-sm mr-2"></i>
            <input type="text" placeholder="Cari sesuatu..." class="bg-transparent border-none outline-none text-sm text-slate-600 w-40">
        </div>

        <div class="relative cursor-pointer group">
            <div class="w-10 h-10 flex items-center justify-center rounded-xl bg-slate-50 text-slate-400 group-hover:bg-blue-50 group-hover:text-blue-600 transition">
                <i class="far fa-bell text-lg"></i>
            </div>
            <span class="absolute top-2 right-2 bg-red-500 w-2 h-2 rounded-full border-2 border-white"></span>
        </div>

        <div class="text-right border-l pl-6 border-slate-100 hidden sm:block">
            <p class="text-sm font-bold text-[#2B3674]"><?= date('l, d M Y'); ?></p>
            <p class="text-xs text-slate-400 font-semibold" id="realtime-clock">00:00:00</p>
        </div>
    </div>
</header>

<script>
    // Script untuk jam real-time
    function updateTime() {
        const now = new Date();
        const options = { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false };
        document.getElementById('realtime-clock').innerText = now.toLocaleTimeString('id-ID', options) + " WIB";
    }
    setInterval(updateTime, 1000);
    updateTime();
</script>