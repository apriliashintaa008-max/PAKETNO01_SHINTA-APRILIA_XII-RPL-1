<footer class="footer mt-auto py-3">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center px-4">
                <div class="footer-copy">
                    <span class="text-muted small fw-bold">© 2025 <a href="#" class="text-decoration-none text-primary">SIPINJAM</a>. All rights reserved.</span>
                </div>
                <div class="footer-links d-none d-md-block">
                    <ul class="list-inline mb-0">
                        <li class="list-inline-item me-4">
                            <a href="#" class="text-muted small text-decoration-none fw-bold">Support</a>
                        </li>
                        <li class="list-inline-item me-4">
                            <a href="#" class="text-muted small text-decoration-none fw-bold">License</a>
                        </li>
                        <li class="list-inline-item">
                            <a href="#" class="text-muted small text-decoration-none fw-bold">Terms of Use</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
</div> <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const currentLocation = location.href;
        const menuItem = document.querySelectorAll('.nav-link');
        const menuLength = menuItem.length;
        for (let i = 0; i < menuLength; i++) {
            if (menuItem[i].href === currentLocation) {
                menuItem[i].className += " active";
            }
        }
    });
</script>

</body>
</html>