<aside class="w-64 bg-[#001b3d] min-h-screen flex flex-col text-white fixed left-0 top-0">
    <div class="p-6 flex items-center gap-3">
        <div class="bg-white/10 p-2 rounded-lg">
            <i class="fas fa-file-signature text-xl"></i>
        </div>
        <h1 class="text-xl font-bold tracking-tight">SIPINJAM</h1>
    </div>

    <nav class="flex-1 px-4 py-4 space-y-1">
        <a href="index.php?page=dashboard" class="flex items-center gap-3 px-4 py-3 rounded-xl bg-blue-600 text-white font-semibold shadow-lg shadow-blue-900/20">
            <i class="fas fa-th-large w-5"></i> Dashboard
        </a>

        <div class="pt-4 pb-2 px-4">
            <p class="text-[10px] font-bold text-gray-400 uppercase tracking-widest">MASTER</p>
        </div>
        <a href="index.php?page=user" class="flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-white/5 transition text-gray-300">
            <i class="fas fa-user w-5"></i> User
        </a>
        <a href="index.php?page=alat" class="flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-white/5 transition text-gray-300">
            <i class="fas fa-tools w-5"></i> Alat
        </a>
        <a href="index.php?page=kategori" class="flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-white/5 transition text-gray-300">
            <i class="fas fa-layer-group w-5"></i> Kategori
        </a>

        <div class="pt-4 pb-2 px-4">
            <p class="text-[10px] font-bold text-gray-400 uppercase tracking-widest">TRANSAKSI</p>
        </div>
        <a href="index.php?page=peminjaman" class="flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-white/5 transition text-gray-300">
            <i class="fas fa-hand-holding w-5"></i> Peminjaman
        </a>
        <a href="index.php?page=pengembalian" class="flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-white/5 transition text-gray-300">
            <i class="fas fa-undo w-5"></i> Pengembalian
        </a>
    </nav>

    <div class="p-4 border-t border-white/10">
        <div class="flex items-center gap-3 bg-white/5 p-3 rounded-2xl">
            <img src="https://ui-avatars.com/api/?name=Admin" class="w-10 h-10 rounded-full border-2 border-blue-500">
            <div>
                <p class="text-sm font-bold">Admin</p>
                <p class="text-[10px] text-gray-400">Administrator</p>
            </div>
            <i class="fas fa-chevron-down ml-auto text-xs text-gray-500"></i>
        </div>
    </div>
</aside>